﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-ONH52Q6\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
