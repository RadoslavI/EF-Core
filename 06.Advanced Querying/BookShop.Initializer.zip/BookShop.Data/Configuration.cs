﻿namespace BookShop.Data
{
    internal class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-ONH52Q6\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
