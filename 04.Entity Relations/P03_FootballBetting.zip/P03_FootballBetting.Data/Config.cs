﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    public static class Config
    {
        public const string ConnectionString = 
            @"Server=DESKTOP-ONH52Q6\SQLEXPRESS;Database=Bet377;Integrated Security=True;";
    }
}
